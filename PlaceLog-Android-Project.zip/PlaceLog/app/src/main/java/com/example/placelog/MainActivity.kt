package com.example.placelog

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CalendarView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.GeofencingClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var geofencingClient: GeofencingClient
    private lateinit var statusText: TextView
    private lateinit var selectedDateText: TextView
    private lateinit var recordsText: TextView
    private lateinit var calendarView: CalendarView
    private var selectedDateStart: Long = dayStart(System.currentTimeMillis())
    private val permissionRequest = 601

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        geofencingClient = LocationServices.getGeofencingClient(this)
        statusText = findViewById(R.id.statusText)
        selectedDateText = findViewById(R.id.selectedDateText)
        recordsText = findViewById(R.id.recordsText)
        calendarView = findViewById(R.id.calendarView)
        findViewById<Button>(R.id.setPlaceButton).setOnClickListener { checkPermissionsThenSetPlace() }
        findViewById<Button>(R.id.startButton).setOnClickListener { checkPermissionsThenStart() }
        findViewById<Button>(R.id.stopButton).setOnClickListener { stopTracking() }
        calendarView.setOnDateChangeListener { _, year, month, day ->
            val c = Calendar.getInstance().apply { set(year, month, day, 0, 0, 0); set(Calendar.MILLISECOND, 0) }
            selectedDateStart = c.timeInMillis
            refreshRecords()
        }
        refreshAll()
    }

    private fun checkPermissionsThenSetPlace() {
        if (!hasForegroundLocation()) { requestLocationPermissions(); return }
        val client = LocationServices.getFusedLocationProviderClient(this)
        try {
            client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, CancellationTokenSource().token)
                .addOnSuccessListener { location ->
                    if (location == null) { toast("Couldn't get location. Turn on Location and try again."); return@addOnSuccessListener }
                    GeoStore.savePlace(this, location.latitude, location.longitude)
                    toast("Place saved. Now start tracking.")
                    refreshAll()
                }.addOnFailureListener { toast("Location failed: ${it.localizedMessage ?: "try again"}") }
        } catch (_: SecurityException) { requestLocationPermissions() }
    }

    private fun checkPermissionsThenStart() {
        if (!hasForegroundLocation()) { requestLocationPermissions(); return }
        if (Build.VERSION.SDK_INT >= 30 && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            AlertDialog.Builder(this).setTitle("Allow background location")
                .setMessage("For automatic arrival/departure detection, set PlaceLog location permission to ‘Allow all the time’ on the next screen.")
                .setPositiveButton("Open settings") { _, _ ->
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                }.setNegativeButton("Cancel", null).show()
            return
        }
        if (!GeoStore.hasPlace(this)) { toast("First set your place while you are there."); return }
        GeofenceHelper.register(this) { ok, error ->
            if (ok) { GeoStore.setActive(this, true); toast("Automatic tracking started."); refreshAll() }
            else toast("Couldn't start tracking: ${error ?: "check permissions and Google Play services"}")
        }
    }

    private fun stopTracking() {
        geofencingClient.removeGeofences(geofencePendingIntent()).addOnCompleteListener {
            GeoStore.setActive(this, false); toast("Tracking stopped. Saved records remain on your phone."); refreshAll()
        }
    }

    private fun geofencePendingIntent(): PendingIntent = GeofenceHelper.pendingIntent(this)

    private fun hasForegroundLocation() = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    private fun requestLocationPermissions() {
        val permissions = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        ActivityCompat.requestPermissions(this, permissions, permissionRequest)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequest) {
            if (hasForegroundLocation()) toast("Location allowed. Tap your action again to continue.") else toast("Location permission is needed for automatic tracking.")
        }
    }

    private fun refreshAll() {
        statusText.text = when {
            GeoStore.isActive(this) -> "● Tracking active · radius 150 m"
            GeoStore.hasPlace(this) -> "Place saved · tracking is off"
            else -> "Set your workplace to begin."
        }
        refreshRecords()
    }

    private fun refreshRecords() {
        val dayEnd = selectedDateStart + 24 * 60 * 60 * 1000L
        val events = GeoStore.events(this).filter { it.timestamp >= selectedDateStart && it.timestamp < dayEnd }
        selectedDateText.text = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date(selectedDateStart))
        if (events.isEmpty()) { recordsText.text = "No records for this date yet."; return }
        val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        val lines = mutableListOf<String>()
        var lastArrival: Long? = null
        var totalMs = 0L
        events.forEach { e ->
            if (e.type == "ARRIVED") {
                lines.add("Arrived   ${timeFormat.format(Date(e.timestamp))}")
                lastArrival = e.timestamp
            } else {
                lines.add("Left        ${timeFormat.format(Date(e.timestamp))}")
                val start = lastArrival
                if (start != null && e.timestamp >= start) { totalMs += e.timestamp - start; lastArrival = null }
            }
        }
        if (lastArrival != null) lines.add("Still checked in (no departure recorded)")
        val hours = totalMs / 3_600_000
        val minutes = (totalMs % 3_600_000) / 60_000
        lines.add("")
        lines.add("Recorded time: ${hours}h ${minutes}m")
        recordsText.text = lines.joinToString("\n")
    }

    private fun dayStart(time: Long): Long = Calendar.getInstance().apply { timeInMillis = time; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
