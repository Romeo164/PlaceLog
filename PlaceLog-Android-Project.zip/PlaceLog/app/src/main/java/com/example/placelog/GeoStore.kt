package com.example.placelog

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object GeoStore {
    private const val PREFS = "placelog_store"
    private const val EVENTS = "events"
    private const val LAT = "latitude"
    private const val LON = "longitude"
    private const val SET = "place_set"
    private const val ACTIVE = "tracking_active"

    data class Event(val timestamp: Long, val type: String)

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun savePlace(context: Context, lat: Double, lon: Double) = prefs(context).edit()
        .putString(LAT, lat.toString()).putString(LON, lon.toString()).putBoolean(SET, true).apply()
    fun hasPlace(context: Context) = prefs(context).getBoolean(SET, false)
    fun latitude(context: Context) = prefs(context).getString(LAT, "0")!!.toDouble()
    fun longitude(context: Context) = prefs(context).getString(LON, "0")!!.toDouble()
    fun setActive(context: Context, active: Boolean) = prefs(context).edit().putBoolean(ACTIVE, active).apply()
    fun isActive(context: Context) = prefs(context).getBoolean(ACTIVE, false)

    @Synchronized fun addEvent(context: Context, timestamp: Long, type: String) {
        val p = prefs(context)
        val array = try { JSONArray(p.getString(EVENTS, "[]")) } catch (_: Exception) { JSONArray() }
        // Ignore duplicate transition events of the same type within 2 minutes.
        if (array.length() > 0) {
            val last = array.optJSONObject(array.length() - 1)
            if (last != null && last.optString("type") == type && kotlin.math.abs(timestamp - last.optLong("timestamp")) < 120_000L) return
        }
        array.put(JSONObject().put("timestamp", timestamp).put("type", type))
        p.edit().putString(EVENTS, array.toString()).apply()
    }

    fun events(context: Context): List<Event> {
        val array = try { JSONArray(prefs(context).getString(EVENTS, "[]")) } catch (_: Exception) { JSONArray() }
        return (0 until array.length()).mapNotNull { i -> array.optJSONObject(i)?.let { Event(it.optLong("timestamp"), it.optString("type")) } }.sortedBy { it.timestamp }
    }
}
