package com.example.placelog

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent

class GeofenceReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val event = GeofencingEvent.fromIntent(intent) ?: return
        if (event.hasError()) return
        val transition = event.geofenceTransition
        val type = when (transition) {
            Geofence.GEOFENCE_TRANSITION_ENTER -> "ARRIVED"
            Geofence.GEOFENCE_TRANSITION_EXIT -> "LEFT"
            else -> return
        }
        GeoStore.addEvent(context, System.currentTimeMillis(), type)
        notifyUser(context, type)
    }

    @Suppress("DEPRECATION")
    private fun notifyUser(context: Context, type: String) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "placelog_events"
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel(channelId, "PlaceLog events", NotificationManager.IMPORTANCE_DEFAULT))
        val message = if (type == "ARRIVED") "Arrival recorded" else "Departure recorded"
        val builder = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(context, channelId) else android.app.Notification.Builder(context)
        val open = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        builder.setSmallIcon(android.R.drawable.ic_menu_mylocation).setContentTitle("PlaceLog").setContentText(message).setContentIntent(open).setAutoCancel(true)
        manager.notify(if (type == "ARRIVED") 101 else 102, builder.build())
    }
}
