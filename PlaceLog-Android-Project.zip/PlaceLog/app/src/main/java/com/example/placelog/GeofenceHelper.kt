package com.example.placelog

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices

object GeofenceHelper {
    private const val REQUEST_CODE = 77
    private const val RADIUS_METERS = 150f

    /** Must stay identical between add and remove so removeGeofences() matches. */
    fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, GeofenceReceiver::class.java)
        // Geofencing needs a mutable PendingIntent on Android 12+. Before that, PendingIntents are mutable by default.
        val mutability = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
        return PendingIntent.getBroadcast(context, REQUEST_CODE, intent, PendingIntent.FLAG_UPDATE_CURRENT or mutability)
    }

    /** Registers the saved place as a geofence. [onResult] is called with (success, errorMessage). */
    fun register(context: Context, onResult: (Boolean, String?) -> Unit) {
        val app = context.applicationContext
        if (!GeoStore.hasPlace(app)) { onResult(false, "No place saved"); return }
        val geofence = Geofence.Builder().setRequestId("primary_place")
            .setCircularRegion(GeoStore.latitude(app), GeoStore.longitude(app), RADIUS_METERS)
            .setExpirationDuration(Geofence.NEVER_EXPIRE)
            .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER or Geofence.GEOFENCE_TRANSITION_EXIT)
            .setLoiteringDelay(60_000).build()
        val request = GeofencingRequest.Builder().setInitialTrigger(0).addGeofence(geofence).build()
        try {
            LocationServices.getGeofencingClient(app).addGeofences(request, pendingIntent(app))
                .addOnSuccessListener { onResult(true, null) }
                .addOnFailureListener { onResult(false, it.localizedMessage) }
        } catch (_: SecurityException) {
            onResult(false, "Location permission is missing")
        }
    }
}
