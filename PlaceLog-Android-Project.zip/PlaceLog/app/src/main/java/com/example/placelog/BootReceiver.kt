package com.example.placelog

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Android removes geofences on reboot and app update, so re-register them if tracking was on. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        if (!GeoStore.isActive(context) || !GeoStore.hasPlace(context)) return
        val pending = goAsync()
        GeofenceHelper.register(context) { ok, _ ->
            // If re-registering failed, show tracking as off so the app doesn't claim something untrue.
            if (!ok) GeoStore.setActive(context, false)
            pending.finish()
        }
    }
}
