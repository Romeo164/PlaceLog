# PlaceLog — Android geofence time log

A small Kotlin Android Studio starter project for Android 11+ (minSdk 30). It records entry/exit events for one saved place and displays a selected day from a calendar. Events are stored locally in SharedPreferences; no account or server is used.

## Build
1. Install Android Studio and Android SDK Platform 35, plus JDK 17.
2. Open this `PlaceLog` folder in Android Studio and allow Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s), then install the APK on your phone.

### Build without Android Studio (GitHub)
1. Create a GitHub repository and upload the *contents* of this folder (so `.github`, `app`, `build.gradle.kts` sit at the repository root).
2. Open the **Actions** tab > **Build APK** > **Run workflow** (it also runs on every push).
3. When the run finishes, open it and download the **PlaceLog-debug-apk** artifact. Unzip it and install `app-debug.apk` on your phone (allow "Install unknown apps" for your browser/file manager).

## First use
1. Turn on phone Location.
2. Open PlaceLog while physically at the location you want to track and tap **Set this location as my place**.
3. In Android App info > Permissions > Location, select **Allow all the time**. Also allow notifications if you want event alerts.
4. Return to PlaceLog and tap **Start automatic tracking**.
5. Keep Google Play services enabled. If events are delayed, set PlaceLog battery usage to Unrestricted / Don't optimize in Android settings.
6. Tap a calendar date to view that day's arrival/departure events.

## Important limitations
- This starter tracks one place with a 150 m radius; it does not have a map picker or multi-place support yet.
- Android geofence events can be delayed by several minutes and may be affected by battery saver, signal, permissions, or device firmware. This is not a payroll-grade time clock.
- Time is calculated from matched arrival/departure events on the same calendar day. An arrival before midnight with departure after midnight is not fully allocated across both days yet.
- Data is stored only on this phone. Clearing app data or uninstalling removes the log; export/backup is not implemented.
- Android removes geofences on reboot and app update. A boot receiver re-registers them automatically if tracking was on; if that fails (for example, background location was revoked), the app shows tracking as off and you need to tap Start again.
- The project source is provided; a compiled APK is not included. The GitHub workflow builds a debug-signed APK, which is fine for installing on your own phone.
